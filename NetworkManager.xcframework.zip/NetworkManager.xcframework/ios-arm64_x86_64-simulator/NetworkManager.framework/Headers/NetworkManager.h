//
//  NetworkManager.h
//  NetworkManager
//
//  Created by Adinarayana Machavarapu on 22/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkManager.
FOUNDATION_EXPORT double NetworkManagerVersionNumber;

//! Project version string for NetworkManager.
FOUNDATION_EXPORT const unsigned char NetworkManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkManager/PublicHeader.h>


